from flask import Flask, render_template, request, redirect
from pymongo import MongoClient

app = Flask(__name__)

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["survey_db"]
collection = db["users"]

@app.route("/", methods=["GET", "POST"])
def index():
    """
    Renders the form and handles form submission.
    When users submit the form, data is stored in MongoDB.
    """
    if request.method == "POST":
        # Collect form data
        data = {
            "name": request.form["name"],
            "age": int(request.form["age"]),
            "gender": request.form["gender"],
            "income": float(request.form["income"]),
            "expenses": {
                "utilities": float(request.form.get("utilities", 0)),
                "entertainment": float(request.form.get("entertainment", 0)),
                "school_fees": float(request.form.get("school_fees", 0)),
                "shopping": float(request.form.get("shopping", 0)),
                "healthcare": float(request.form.get("healthcare", 0))
            }
        }

        # Insert data into MongoDB
        collection.insert_one(data)

        return redirect("/")
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
