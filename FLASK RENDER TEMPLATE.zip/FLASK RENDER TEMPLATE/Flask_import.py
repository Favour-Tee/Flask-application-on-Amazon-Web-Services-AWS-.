from flask import Flask, render_template, request, redirect
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
db = client["surveyDB"]
collection = db["user_data"]

@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        data = {
            "age": request.form['age'],
            "gender": request.form['gender'],
            "income": request.form['income'],
            "expenses": {category: request.form.get(category, 0) for category in ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']}
        }
        collection.insert_one(data)
        return redirect('/')
    return render_template('form.html')

if __name__ == '__main__':
    app.run(debug=True)

    import pandas as pd
from pymongo import MongoClient

class User:
    def __init__(self):
        self.client = MongoClient("mongodb://localhost:27017/")
        self.db = self.client["surveyDB"]
        self.collection = self.db["user_data"]

    def export_to_csv(self, filename="survey_data.csv"):
        data = list(self.collection.find({}, {"_id": 0}))
        df = pd.DataFrame(data)
        df.to_csv(filename, index=False)
        print("Data exported to", filename)

# Example usage
if __name__ == "__main__":
    user = User()
    user.export_to_csv()